=== Modern view ===
Contributors: (your_username)
Tags: modern, responsive, customizable
Requires at least: 5.0
Tested up to: 6.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

My Theme is a modern and stylish WordPress theme that is easy to customize and perfect for any website. It features a clean design and user-friendly interface.

== Installation ==

1. Upload the `my-theme` folder to the `/wp-content/themes/` directory.
2. Activate the theme through the 'Themes' menu in WordPress.
3. Customize your theme using the 'Customize' option under the Appearance menu.

== Frequently Asked Questions ==

= How do I customize my theme? =

You can customize your theme using the WordPress Customizer under Appearance > Customize.

= Where can I find support? =

For support, please visit our support page or email support@yourwebsite.com.

== Changelog ==

= 1.0 =
* Initial release.
